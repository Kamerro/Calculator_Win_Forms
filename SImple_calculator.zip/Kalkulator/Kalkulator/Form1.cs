﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kalkulator
{
    public partial class Form1 : Form
    {
        private interface IDzialania_M
        {
            string Dodaj(double czlon_1,double czlon_2);
            string Odejmij(double czlon_1, double czlon_2);
            string Mnoz(double czlon_1, double czlon_2);
            string Dziel(double czlon_1, double czlon_2);
        }
        private interface IOperacje_M
        {
            void Kropkuj();
            string Wyswietl_Wynik();
            string Zeruj();
            void Skasuj_Ostatnie();
        }


        public Form1()
        {
            InitializeComponent();
           calc = new Kalkulator();
        }
        private void czyszczenieRichTextBox()
        {
            richTextBox1.Clear();

        }
        Kalkulator calc;
        public class Kalkulator : IOperacje_M, IDzialania_M
        {

            //pierwszy oraz długi człon określają liczby, na których będą wykonywane operacje.
            private double pierwszy_czlon;
            private double drugi_czlon;
            private bool aktualnie_pierwszy;
            //Wynik przechowuje wynik operacji.
            private double wynik;
            private string operand;
            private bool kropkowanie = false;
            private int numer_po_kropce=1;

            public Kalkulator(int wynik = 0)
            {
                this.wynik = wynik;
                this.aktualnie_pierwszy = true;
            }

            public string get_Wynik_operacji_bckspace()
            {
                if (this.aktualnie_pierwszy)
                {
                    return this.pierwszy_czlon.ToString();
                }else
                    return this.drugi_czlon.ToString();
            }

            public string wartosciowanie(int wartosc)
            {
                if (!kropkowanie)
                {
                    if (this.aktualnie_pierwszy)
                    {
                        this.pierwszy_czlon *= 10;
                        this.pierwszy_czlon += wartosc;
                        return this.pierwszy_czlon.ToString();
                    }
                    this.drugi_czlon *= 10;
                    this.drugi_czlon += wartosc;
                    return this.drugi_czlon.ToString();
                }
                else{
                    
                    if (this.aktualnie_pierwszy)
                    {
                        this.pierwszy_czlon += wartosc / (Math.Pow(10, this.numer_po_kropce));
                        this.numer_po_kropce++;
                        return this.pierwszy_czlon.ToString();
                    }
                    this.drugi_czlon += wartosc / (Math.Pow(10, this.numer_po_kropce));
                    this.numer_po_kropce++;
                    return this.drugi_czlon.ToString();
                }
            }

            public void Operand(string znak)
            {
                this.operand = znak;
                this.numer_po_kropce = 1;
                this.kropkowanie = false;
            }

            public void zmien_czlon()
            {
                this.aktualnie_pierwszy = false;
            }

            public void Kropkuj()
            {
                this.kropkowanie=!this.kropkowanie;
            }

            public string Wyswietl_Wynik()
            {
                if (this.operand == "/")
                {
                    this.wynik = pierwszy_czlon / drugi_czlon;
                }
                else if (this.operand == "*")
                {
                    this.wynik = this.pierwszy_czlon * this.drugi_czlon;
                }
                else if (this.operand == "-")
                {
                    this.wynik = this.pierwszy_czlon - this.drugi_czlon;
                }
                else if (this.operand == "+")
                {
                    this.wynik = this.pierwszy_czlon + this.drugi_czlon;
                }
                this.aktualnie_pierwszy = true;
                this.kropkowanie = false;
                this.numer_po_kropce = 1;
                this.pierwszy_czlon = this.wynik;
                this.drugi_czlon = 0;
                return this.wynik.ToString();
            }
            public string Zeruj()
            {
               
                this.pierwszy_czlon = 0;
                this.drugi_czlon = 0;
                this.wynik = 0;
                this.aktualnie_pierwszy = true;
                this.kropkowanie = false;
                this.numer_po_kropce = 1;
                this.pierwszy_czlon = this.wynik;
                this.drugi_czlon = 0;
                return this.wynik.ToString();
            }

            public void Zablokuj_Przycisk(Button btn)
            {
                btn.Enabled = false;
            }
            public void Odblokuj_Przycisk(Button btn)
            {
                btn.Enabled = true;
            }
            public void Skasuj_Ostatnie()
            {
                if (!this.kropkowanie)
                {
                    if (this.aktualnie_pierwszy)
                    {
                        this.pierwszy_czlon -= this.pierwszy_czlon % 10;
                        this.pierwszy_czlon /= 10;
                    }
                    else
                    {
                        this.drugi_czlon -= this.drugi_czlon % 10;
                        this.drugi_czlon /= 10;
                    }
                }
                else
                {
                    
                    this.numer_po_kropce--;
                    if (this.aktualnie_pierwszy)
                    {
                        this.pierwszy_czlon -= (this.pierwszy_czlon) % Math.Pow(10, -this.numer_po_kropce+1);
                        MessageBox.Show(this.pierwszy_czlon.ToString());
                    }
                    else
                    {
                        this.drugi_czlon -= this.drugi_czlon % Math.Pow(10, -this.numer_po_kropce+1);

                    }
                    if (this.numer_po_kropce == 1) this.kropkowanie = false;
                }
            }
            public string Dodaj(double czlon_1, double czlon_2)
            {
                this.wynik = czlon_1 + czlon_2;
                this.pierwszy_czlon = wynik;
                return wynik.ToString();
            }

            public string Odejmij(double czlon_1, double czlon_2)
            {
                this.wynik = czlon_1 - czlon_2;
                this.pierwszy_czlon = wynik;
                return wynik.ToString();
            }

            public string Mnoz(double czlon_1, double czlon_2)
            {
                this.wynik = czlon_1 * czlon_2;
                this.pierwszy_czlon = wynik;
                return wynik.ToString();
            }

            public string Dziel(double czlon_1, double czlon_2)
            {
                if (czlon_2 != 0)
                {
                    this.wynik = czlon_1 / czlon_2;
                    this.pierwszy_czlon = wynik;
                    return wynik.ToString();
                }
                else return "INFINITY";
            }
        }


        private void btn_0_Click(object sender, EventArgs e)
        {
            czyszczenieRichTextBox();
            richTextBox1.AppendText(calc.wartosciowanie(0));
        }

        private void btn_1_Click(object sender, EventArgs e)
        {
            czyszczenieRichTextBox();
            richTextBox1.AppendText(calc.wartosciowanie(1));
        }

        private void btn_2_Click(object sender, EventArgs e)
        {
            czyszczenieRichTextBox();
            richTextBox1.AppendText(calc.wartosciowanie(2));
        }

        private void btn_3_Click(object sender, EventArgs e)
        {
            czyszczenieRichTextBox();
            richTextBox1.AppendText(calc.wartosciowanie(3));
        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            czyszczenieRichTextBox();
            richTextBox1.AppendText(calc.wartosciowanie(4));
        }

        private void btn_5_Click(object sender, EventArgs e)
        {
            czyszczenieRichTextBox();
            richTextBox1.AppendText(calc.wartosciowanie(5));
        }

        private void btn_6_Click(object sender, EventArgs e)
        {
            czyszczenieRichTextBox();
            richTextBox1.AppendText(calc.wartosciowanie(6));
        }

        private void btn_7_Click(object sender, EventArgs e)
        {
            czyszczenieRichTextBox();
            richTextBox1.AppendText(calc.wartosciowanie(7));
        }

        private void btn_8_Click(object sender, EventArgs e)
        {
            czyszczenieRichTextBox();
            richTextBox1.AppendText(calc.wartosciowanie(8));
        }

        private void btn_9_Click(object sender, EventArgs e)
        {
            czyszczenieRichTextBox();
            richTextBox1.AppendText(calc.wartosciowanie(9));
        }

        private void btn_dodaj_Click(object sender, EventArgs e)
        {
            calc.zmien_czlon();
            calc.Operand("+");
            richTextBox1.Clear();
            richTextBox1.Update();
            calc.Odblokuj_Przycisk(btn_bckspc);
        }

        private void btn_dziel_Click(object sender, EventArgs e)
        {
            calc.zmien_czlon();
            calc.Operand("/");
            richTextBox1.Clear();
            richTextBox1.Update();
            calc.Odblokuj_Przycisk(btn_bckspc);
        }

        private void btn_minus_Click(object sender, EventArgs e)
        {
            calc.zmien_czlon();
            calc.Operand("-");
            richTextBox1.Clear();
            richTextBox1.Update();
            calc.Odblokuj_Przycisk(btn_bckspc);
        }

        private void btn_razy_Click(object sender, EventArgs e)
        {
            calc.zmien_czlon();
            calc.Operand("*");
            richTextBox1.Clear();
            richTextBox1.Update();
            calc.Odblokuj_Przycisk(btn_bckspc);
        }


        private void btn_rowna_Click_1(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            richTextBox1.AppendText(calc.Wyswietl_Wynik());
            richTextBox1.Update();
            calc.Zablokuj_Przycisk(btn_bckspc);
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
  
           richTextBox1.Clear();
           richTextBox1.AppendText(calc.Zeruj());
           calc.Odblokuj_Przycisk(btn_bckspc);

        }

        private void btn_kropka_Click(object sender, EventArgs e)
        {
            calc.Kropkuj();
        }

        private void btn_bckspc_Click(object sender, EventArgs e)
        {
            calc.Skasuj_Ostatnie();
            richTextBox1.Clear();
            richTextBox1.AppendText(calc.get_Wynik_operacji_bckspace());
        }
    }
}
