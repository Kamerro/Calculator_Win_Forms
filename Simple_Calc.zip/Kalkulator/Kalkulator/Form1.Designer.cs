﻿
namespace Kalkulator
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_7 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btn_8 = new System.Windows.Forms.Button();
            this.btn_9 = new System.Windows.Forms.Button();
            this.btn_dziel = new System.Windows.Forms.Button();
            this.btn_dodaj = new System.Windows.Forms.Button();
            this.btn_minus = new System.Windows.Forms.Button();
            this.btn_rowna = new System.Windows.Forms.Button();
            this.btn_4 = new System.Windows.Forms.Button();
            this.btn_5 = new System.Windows.Forms.Button();
            this.btn_6 = new System.Windows.Forms.Button();
            this.btn_1 = new System.Windows.Forms.Button();
            this.btn_2 = new System.Windows.Forms.Button();
            this.btn_3 = new System.Windows.Forms.Button();
            this.btn_razy = new System.Windows.Forms.Button();
            this.btn_0 = new System.Windows.Forms.Button();
            this.btn_kropka = new System.Windows.Forms.Button();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.btn_bckspc = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_7
            // 
            this.btn_7.BackColor = System.Drawing.Color.IndianRed;
            this.btn_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_7.ForeColor = System.Drawing.Color.Snow;
            this.btn_7.Location = new System.Drawing.Point(12, 128);
            this.btn_7.Name = "btn_7";
            this.btn_7.Size = new System.Drawing.Size(100, 100);
            this.btn_7.TabIndex = 0;
            this.btn_7.Text = "7";
            this.btn_7.UseVisualStyleBackColor = false;
            this.btn_7.Click += new System.EventHandler(this.btn_7_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(12, 12);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(524, 96);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // btn_8
            // 
            this.btn_8.BackColor = System.Drawing.Color.IndianRed;
            this.btn_8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_8.ForeColor = System.Drawing.Color.Snow;
            this.btn_8.Location = new System.Drawing.Point(118, 128);
            this.btn_8.Name = "btn_8";
            this.btn_8.Size = new System.Drawing.Size(100, 100);
            this.btn_8.TabIndex = 2;
            this.btn_8.Text = "8";
            this.btn_8.UseVisualStyleBackColor = false;
            this.btn_8.Click += new System.EventHandler(this.btn_8_Click);
            // 
            // btn_9
            // 
            this.btn_9.BackColor = System.Drawing.Color.IndianRed;
            this.btn_9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_9.ForeColor = System.Drawing.Color.Snow;
            this.btn_9.Location = new System.Drawing.Point(224, 128);
            this.btn_9.Name = "btn_9";
            this.btn_9.Size = new System.Drawing.Size(100, 100);
            this.btn_9.TabIndex = 3;
            this.btn_9.Text = "9";
            this.btn_9.UseVisualStyleBackColor = false;
            this.btn_9.Click += new System.EventHandler(this.btn_9_Click);
            // 
            // btn_dziel
            // 
            this.btn_dziel.BackColor = System.Drawing.Color.DarkOrange;
            this.btn_dziel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_dziel.ForeColor = System.Drawing.Color.Snow;
            this.btn_dziel.Location = new System.Drawing.Point(332, 454);
            this.btn_dziel.Name = "btn_dziel";
            this.btn_dziel.Size = new System.Drawing.Size(100, 100);
            this.btn_dziel.TabIndex = 4;
            this.btn_dziel.Text = "/";
            this.btn_dziel.UseVisualStyleBackColor = false;
            this.btn_dziel.Click += new System.EventHandler(this.btn_dziel_Click);
            // 
            // btn_dodaj
            // 
            this.btn_dodaj.BackColor = System.Drawing.Color.DarkOrange;
            this.btn_dodaj.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_dodaj.ForeColor = System.Drawing.Color.Snow;
            this.btn_dodaj.Location = new System.Drawing.Point(332, 128);
            this.btn_dodaj.Name = "btn_dodaj";
            this.btn_dodaj.Size = new System.Drawing.Size(100, 100);
            this.btn_dodaj.TabIndex = 5;
            this.btn_dodaj.Text = "+";
            this.btn_dodaj.UseVisualStyleBackColor = false;
            this.btn_dodaj.Click += new System.EventHandler(this.btn_dodaj_Click);
            // 
            // btn_minus
            // 
            this.btn_minus.BackColor = System.Drawing.Color.DarkOrange;
            this.btn_minus.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_minus.ForeColor = System.Drawing.Color.Snow;
            this.btn_minus.Location = new System.Drawing.Point(330, 238);
            this.btn_minus.Name = "btn_minus";
            this.btn_minus.Size = new System.Drawing.Size(100, 100);
            this.btn_minus.TabIndex = 6;
            this.btn_minus.Text = "-";
            this.btn_minus.UseVisualStyleBackColor = false;
            this.btn_minus.Click += new System.EventHandler(this.btn_minus_Click);
            // 
            // btn_rowna
            // 
            this.btn_rowna.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_rowna.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_rowna.ForeColor = System.Drawing.Color.Snow;
            this.btn_rowna.Location = new System.Drawing.Point(436, 344);
            this.btn_rowna.Name = "btn_rowna";
            this.btn_rowna.Size = new System.Drawing.Size(100, 210);
            this.btn_rowna.TabIndex = 5;
            this.btn_rowna.Text = "=";
            this.btn_rowna.UseVisualStyleBackColor = false;
            this.btn_rowna.Click += new System.EventHandler(this.btn_rowna_Click_1);
            // 
            // btn_4
            // 
            this.btn_4.BackColor = System.Drawing.Color.IndianRed;
            this.btn_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_4.ForeColor = System.Drawing.Color.Snow;
            this.btn_4.Location = new System.Drawing.Point(12, 238);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(100, 100);
            this.btn_4.TabIndex = 7;
            this.btn_4.Text = "4";
            this.btn_4.UseVisualStyleBackColor = false;
            this.btn_4.Click += new System.EventHandler(this.btn_4_Click);
            // 
            // btn_5
            // 
            this.btn_5.BackColor = System.Drawing.Color.IndianRed;
            this.btn_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_5.ForeColor = System.Drawing.Color.Snow;
            this.btn_5.Location = new System.Drawing.Point(118, 238);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(100, 100);
            this.btn_5.TabIndex = 8;
            this.btn_5.Text = "5";
            this.btn_5.UseVisualStyleBackColor = false;
            this.btn_5.Click += new System.EventHandler(this.btn_5_Click);
            // 
            // btn_6
            // 
            this.btn_6.BackColor = System.Drawing.Color.IndianRed;
            this.btn_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_6.ForeColor = System.Drawing.Color.Snow;
            this.btn_6.Location = new System.Drawing.Point(224, 238);
            this.btn_6.Name = "btn_6";
            this.btn_6.Size = new System.Drawing.Size(100, 100);
            this.btn_6.TabIndex = 9;
            this.btn_6.Text = "6";
            this.btn_6.UseVisualStyleBackColor = false;
            this.btn_6.Click += new System.EventHandler(this.btn_6_Click);
            // 
            // btn_1
            // 
            this.btn_1.BackColor = System.Drawing.Color.IndianRed;
            this.btn_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_1.ForeColor = System.Drawing.Color.Snow;
            this.btn_1.Location = new System.Drawing.Point(12, 344);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(100, 100);
            this.btn_1.TabIndex = 10;
            this.btn_1.Text = "1";
            this.btn_1.UseVisualStyleBackColor = false;
            this.btn_1.Click += new System.EventHandler(this.btn_1_Click);
            // 
            // btn_2
            // 
            this.btn_2.BackColor = System.Drawing.Color.IndianRed;
            this.btn_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_2.ForeColor = System.Drawing.Color.Snow;
            this.btn_2.Location = new System.Drawing.Point(118, 344);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(100, 100);
            this.btn_2.TabIndex = 11;
            this.btn_2.Text = "2";
            this.btn_2.UseVisualStyleBackColor = false;
            this.btn_2.Click += new System.EventHandler(this.btn_2_Click);
            // 
            // btn_3
            // 
            this.btn_3.BackColor = System.Drawing.Color.IndianRed;
            this.btn_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_3.ForeColor = System.Drawing.Color.Snow;
            this.btn_3.Location = new System.Drawing.Point(224, 344);
            this.btn_3.Name = "btn_3";
            this.btn_3.Size = new System.Drawing.Size(100, 100);
            this.btn_3.TabIndex = 12;
            this.btn_3.Text = "3";
            this.btn_3.UseVisualStyleBackColor = false;
            this.btn_3.Click += new System.EventHandler(this.btn_3_Click);
            // 
            // btn_razy
            // 
            this.btn_razy.BackColor = System.Drawing.Color.DarkOrange;
            this.btn_razy.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_razy.ForeColor = System.Drawing.Color.Snow;
            this.btn_razy.Location = new System.Drawing.Point(330, 344);
            this.btn_razy.Name = "btn_razy";
            this.btn_razy.Size = new System.Drawing.Size(100, 100);
            this.btn_razy.TabIndex = 13;
            this.btn_razy.Text = "*";
            this.btn_razy.UseVisualStyleBackColor = false;
            this.btn_razy.Click += new System.EventHandler(this.btn_razy_Click);
            // 
            // btn_0
            // 
            this.btn_0.BackColor = System.Drawing.Color.IndianRed;
            this.btn_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_0.ForeColor = System.Drawing.Color.Snow;
            this.btn_0.Location = new System.Drawing.Point(12, 454);
            this.btn_0.Name = "btn_0";
            this.btn_0.Size = new System.Drawing.Size(206, 100);
            this.btn_0.TabIndex = 14;
            this.btn_0.Text = "0";
            this.btn_0.UseVisualStyleBackColor = false;
            this.btn_0.Click += new System.EventHandler(this.btn_0_Click);
            // 
            // btn_kropka
            // 
            this.btn_kropka.BackColor = System.Drawing.Color.IndianRed;
            this.btn_kropka.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_kropka.ForeColor = System.Drawing.Color.Snow;
            this.btn_kropka.Location = new System.Drawing.Point(224, 454);
            this.btn_kropka.Name = "btn_kropka";
            this.btn_kropka.Size = new System.Drawing.Size(100, 100);
            this.btn_kropka.TabIndex = 15;
            this.btn_kropka.Text = ".";
            this.btn_kropka.UseVisualStyleBackColor = false;
            this.btn_kropka.Click += new System.EventHandler(this.btn_kropka_Click);
            // 
            // btn_Clear
            // 
            this.btn_Clear.BackColor = System.Drawing.Color.Sienna;
            this.btn_Clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btn_Clear.ForeColor = System.Drawing.Color.Snow;
            this.btn_Clear.Location = new System.Drawing.Point(438, 238);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(100, 100);
            this.btn_Clear.TabIndex = 16;
            this.btn_Clear.Text = "C";
            this.btn_Clear.UseVisualStyleBackColor = false;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_bckspc
            // 
            this.btn_bckspc.BackColor = System.Drawing.Color.Sienna;
            this.btn_bckspc.Font = new System.Drawing.Font("Microsoft YaHei", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_bckspc.ForeColor = System.Drawing.Color.Snow;
            this.btn_bckspc.Location = new System.Drawing.Point(438, 128);
            this.btn_bckspc.Name = "btn_bckspc";
            this.btn_bckspc.Size = new System.Drawing.Size(100, 100);
            this.btn_bckspc.TabIndex = 17;
            this.btn_bckspc.Text = "<-";
            this.btn_bckspc.UseVisualStyleBackColor = false;
            this.btn_bckspc.Click += new System.EventHandler(this.btn_bckspc_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(550, 562);
            this.Controls.Add(this.btn_bckspc);
            this.Controls.Add(this.btn_Clear);
            this.Controls.Add(this.btn_kropka);
            this.Controls.Add(this.btn_0);
            this.Controls.Add(this.btn_razy);
            this.Controls.Add(this.btn_3);
            this.Controls.Add(this.btn_2);
            this.Controls.Add(this.btn_1);
            this.Controls.Add(this.btn_6);
            this.Controls.Add(this.btn_5);
            this.Controls.Add(this.btn_4);
            this.Controls.Add(this.btn_minus);
            this.Controls.Add(this.btn_rowna);
            this.Controls.Add(this.btn_dodaj);
            this.Controls.Add(this.btn_dziel);
            this.Controls.Add(this.btn_9);
            this.Controls.Add(this.btn_8);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.btn_7);
            this.Name = "Form1";
            this.Text = "Kalkulator";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_7;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button btn_8;
        private System.Windows.Forms.Button btn_9;
        private System.Windows.Forms.Button btn_dziel;
        private System.Windows.Forms.Button btn_dodaj;
        private System.Windows.Forms.Button btn_minus;
        private System.Windows.Forms.Button btn_rowna;
        private System.Windows.Forms.Button btn_4;
        private System.Windows.Forms.Button btn_5;
        private System.Windows.Forms.Button btn_6;
        private System.Windows.Forms.Button btn_1;
        private System.Windows.Forms.Button btn_2;
        private System.Windows.Forms.Button btn_3;
        private System.Windows.Forms.Button btn_razy;
        private System.Windows.Forms.Button btn_0;
        private System.Windows.Forms.Button btn_kropka;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.Button btn_bckspc;
    }
}

